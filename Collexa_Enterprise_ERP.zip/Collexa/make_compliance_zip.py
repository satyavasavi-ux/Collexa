﻿import os
import zipfile

source_dir = r"c:\Users\ADMIN\Downloads\Collexa"
zip_path = r"c:\Users\ADMIN\Downloads\Collexa_Enterprise_ERP.zip"

exclude_dirs = {"myenv", "node_modules", "__pycache__", "dist", "build", ".venv", ".next", ".vscode", ".idea", ".pytest_cache"}
exclude_extensions = {".pyc", ".pyd", ".zip"}

file_count = 0
git_file_count = 0
total_bytes = 0

with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(source_dir):
        # Filter out heavy cache and env directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            ext = os.path.splitext(file)[1].lower()
            if ext in exclude_extensions:
                continue
            if file == "Collexa_Enterprise_ERP.zip":
                continue
            if file == ".env" or file.endswith(".env"):
                continue
                
            full_path = os.path.join(root, file)
            rel_path = os.path.relpath(full_path, source_dir)
            
            # Write to zip preserving directory structure
            zipf.write(full_path, os.path.join("Collexa", rel_path))
            file_count += 1
            if ".git" in rel_path.split(os.sep):
                git_file_count += 1
            total_bytes += os.path.getsize(full_path)

zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
print(f"==================================================")
print(f"  ZIP ARCHIVE GENERATION REPORT                   ")
print(f"==================================================")
print(f"Archive Destination:     {zip_path}")
print(f"Total Files Packaged:    {file_count}")
print(f"Git History Files:       {git_file_count}")
print(f"Uncompressed Total Size: {total_bytes / 1024:.1f} KB")
print(f"Compressed ZIP Size:     {zip_size_mb:.2f} MB")
print(f"==================================================")
